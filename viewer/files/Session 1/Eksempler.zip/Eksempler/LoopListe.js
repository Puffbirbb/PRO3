let liste = ['Ole', 'Ib', 'Oda'];
for(let i = 0;i<liste.length;i++) {
    if (liste[i] == "Ib") {
        console.log("Fundet på plads " + i);
    }
}
