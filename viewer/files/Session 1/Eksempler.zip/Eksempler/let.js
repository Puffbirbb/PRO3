// let.js
let x, y = 123;
console.log(x); // => undefined
console.log(y); // => 123
y = 'test';
console.log(y); // => test
y = null;
console.log(y); // => null