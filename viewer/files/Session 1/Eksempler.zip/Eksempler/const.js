// const.js
const x = 123;
console.log(x); // => 123
x = 'test'; // => TypeError: Assignment to constant variable