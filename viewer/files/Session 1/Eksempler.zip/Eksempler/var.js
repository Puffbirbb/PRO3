// var.js
console.log(x); // => undefined
var x = 123;
console.log(x); // => 123
console.log(y); // => ReferenceError: y is not defined
let y = 456;